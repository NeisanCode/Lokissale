<?php require "inc/haut.inc.php" ?>
<?php require "inc/menu.inc.php" ?>
<?php require "../backend/newsletter.php" ?>




<main class="container newsletter-container">
    <h2>Newsletter LOKISALLE</h2>

    <?php if (!$isConnected): ?>
        <!-- Message pour les visiteurs non connectés -->
        <div class="warning-box">
            <strong>⚠️ Attention :</strong> Vous devez être membre de LOKISALLE pour vous abonner à notre newsletter.
        </div>
        <p>La newsletter est un service exclusif réservé à nos membres.</p>
        <p>
            <a href="inscription.php" class="btn-subscribe" style="color:white; text-decoration:none">Créer un compte</a>
            ou
            <a href="connexion.php" style="color: #1abc9c; font-weight: bold;">Se connecter</a>
        </p>

    <?php elseif ($message === 'success'): ?>
        <!-- Message de confirmation d'inscription -->
        <div class="success-box">
            <strong>✓ Félicitations !</strong> Vous êtes maintenant abonné(e) à notre newsletter.
        </div>
        <div class="newsletter-box">
            <div class="newsletter-icon">📧</div>
            <h3>Bienvenue parmi nos abonnés !</h3>
            <p>Vous recevrez désormais toutes nos actualités, offres exclusives et promotions directement dans votre
                boîte mail.</p>
        </div>
        <form method="POST" style="margin-top: 20px;">
            <button type="submit" name="unsubscribe"
                style="background: #e74c3c; padding: 10px 25px; color: white; border: none; border-radius: 5px; cursor: pointer;">
                Se désabonner
            </button>
        </form>

    <?php elseif ($message === 'unsubscribed'): ?>
        <!-- Message de désinscription -->
        <div class="warning-box">
            Vous avez été désabonné(e) de notre newsletter. Vous ne recevrez plus nos communications.
        </div>
        <p>Vous pouvez vous réabonner à tout moment en revenant sur cette page.</p>

    <?php elseif ($isSubscribed): ?>
        <!-- Déjà abonné -->
        <div class="success-box">
            <strong>✓ Vous êtes déjà abonné(e)</strong> à notre newsletter.
        </div>
        <div class="newsletter-box">
            <div class="newsletter-icon">📬</div>
            <h3>Merci pour votre fidélité !</h3>
            <p>Vous recevez déjà nos actualités et promotions exclusives.</p>
        </div>
        <form method="POST" style="margin-top: 20px;">
            <button type="submit" name="unsubscribe"
                style="background: #e74c3c; padding: 10px 25px; color: white; border: none; border-radius: 5px; cursor: pointer;">
                Se désabonner
            </button>
        </form>

    <?php else: ?>
        <!-- Formulaire d'inscription pour membre non abonné -->
        <div class="newsletter-box">
            <div class="newsletter-icon">📬</div>
            <h3>Restez informé(e) de nos actualités !</h3>
            <p>Abonnez-vous à notre newsletter et ne manquez aucune de nos offres exclusives.</p>
        </div>

        <div class="newsletter-benefits">
            <h3>Les avantages de notre newsletter :</h3>
            <ul>
                <li>Recevez en avant-première nos nouvelles offres de salles</li>
                <li>Bénéficiez de promotions et codes promo exclusifs</li>
                <li>Découvrez nos conseils pour organiser vos événements</li>
                <li>Soyez informé(e) de l'ouverture de nouvelles salles</li>
                <li>Accédez à des tarifs préférentiels réservés aux abonnés</li>
            </ul>
        </div>

        <form method="POST">
            <button type="submit" name="subscribe" class="btn-subscribe">
                ✉️ S'abonner à la newsletter
            </button>
        </form>

        <p style="margin-top: 20px; font-size: 14px; color: #666;">
            Vous pourrez vous désabonner à tout moment en un clic.
        </p>
    <?php endif; ?>

    <div style="margin-top: 40px; padding: 20px; background: #f8f9fa; border-radius: 5px;">
        <h3>Fréquence d'envoi</h3>
        <p>Notre newsletter est envoyée 2 à 4 fois par mois, selon l'actualité de LOKISALLE.</p>
        <p style="font-size: 14px; color: #666;">
            Vos données sont protégées et ne seront jamais communiquées à des tiers.
            Conformément au RGPD, vous disposez d'un droit d'accès et de modification de vos informations.
        </p>
    </div>
</main>



<?php require "inc/bas.inc.php" ?>